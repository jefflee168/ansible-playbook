ps -ef|grep zabbix3|grep -v grep|awk '{print $2}'|xargs kill -9
rm -f /opt/zabbix3/zabbix_agentd.pid > /dev/null
