rm -f /opt/zabbix3/zabbix_agentd.pid > /dev/null
/opt/zabbix3/sbin/zabbix_agentd -c /opt/zabbix3/conf/zabbix_agentd.conf
